// src/pages/Home.jsx
import { useNavigate } from "react-router";
import Header from "../components/Header";
import Footer from "../components/Footer";
import MangaCard from "../components/MangaCard";
import { useState } from "react";

export default function Home() {
    const navigate = useNavigate();
    const [query, setQuery] = useState("");

    // Mock trending data (no API yet)
    const trending = [
        { id: 1, title: "Naruto", rating: 9.1 },
        { id: 2, title: "One Piece", rating: 9.5 },
        { id: 3, title: "Attack on Titan", rating: 9.3 },
        { id: 4, title: "Demon Slayer", rating: 8.9 },
        { id: 5, title: "Jujutsu Kaisen", rating: 9.0 },
        { id: 6, title: "Death Note", rating: 9.2 },
        { id: 7, title: "Bleach", rating: 8.7 },
        { id: 8, title: "Chainsaw Man", rating: 8.8 }
    ];

    // Handle search submit
    const handleSearch = (e) => {
        e.preventDefault();
        if (!query) return;

        navigate(`/search?q=${query}`);
    };

    return (
        <div className="min-h-screen bg-linear-to-br from-black via-purple-950 to-black text-white selection:bg-purple-500/30">
            {/* Header */}
            <Header />

            {/* Hero Search Section */}
            <section className="relative flex flex-col items-center justify-center py-24 md:py-32 overflow-hidden">
                {/* Background glow effect */}
                <div className="absolute inset-0 -z-10 bg-[radial-linear(ellipse_at_center,_var(--tw-linear-stops))] from-purple-900/20 via-transparent to-transparent opacity-70"></div>

                <div className="text-center max-w-4xl mx-auto px-4">
                    {/* Decorative badge */}
                    <div className="inline-flex items-center gap-2 bg-purple-950/40 border border-purple-500/30 rounded-full px-4 py-1.5 text-sm text-purple-300 mb-6 backdrop-blur-sm">
                        <span className="relative flex h-2.5 w-2.5">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-purple-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-purple-500"></span>
                        </span>
                        #1 Manga Discovery Platform
                    </div>

                    {/* Main heading */}
                    <h1 className="text-5xl md:text-6xl lg:text-7xl font-black leading-tight mb-4">
                        <span className="bg-linear-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent">
                            Discover Manga
                        </span>
                        <br />
                        <span className="text-white/90">Beyond Imagination</span>
                    </h1>
                    <p className="text-gray-400 text-lg md:text-xl mb-10 max-w-2xl mx-auto leading-relaxed">
                        Explore thousands of titles, find hidden gems, and keep track of your favorites — all in one place.
                    </p>

                    {/* Search form */}
                    <form
                        onSubmit={handleSearch}
                        className="flex flex-col sm:flex-row items-center justify-center gap-3 w-full max-w-xl mx-auto"
                    >
                        <div className="relative w-full">
                            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-purple-400/60 text-lg">
                                🔍
                            </span>
                            <input
                                value={query}
                                onChange={(e) => setQuery(e.target.value)}
                                placeholder="Search for manga, author, or genre..."
                                className="w-full pl-12 pr-4 py-4 rounded-2xl bg-gray-900/80 border border-purple-800/50 text-white placeholder-gray-500 focus:outline-none focus:border-purple-500 focus:ring-2 focus:ring-purple-500/30 backdrop-blur-sm transition-all duration-200 shadow-lg shadow-purple-900/20"
                            />
                        </div>
                        <button
                            type="submit"
                            className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-linear-to-r from-purple-600 to-blue-600 text-white font-bold text-lg hover:shadow-xl hover:shadow-purple-500/40 hover:scale-105 transition-all duration-200 active:scale-95"
                        >
                            Explore
                        </button>
                    </form>
                </div>
            </section>

            {/* Trending Section */}
            <section className="max-w-7xl mx-auto px-6 pb-16">
                {/* Section header */}
                <div className="flex items-center justify-between mb-8">
                    <div>
                        <h2 className="text-3xl font-bold bg-linear-to-r from-purple-300 to-blue-300 bg-clip-text text-transparent">
                            🔥 Top Trending Manga
                        </h2>
                        <p className="text-gray-400 mt-1">Most popular this week</p>
                    </div>
                    <span className="hidden sm:block text-purple-300 hover:text-purple-200 cursor-pointer text-sm font-medium transition-colors">
                        View all →
                    </span>
                </div>

                {/* Grid - responsive */}
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-5">
                    {trending.map((manga) => (
                        <MangaCard key={manga.id} manga={manga} />
                    ))}
                </div>
            </section>

            {/* Footer */}
            <Footer />
        </div>
    );
}