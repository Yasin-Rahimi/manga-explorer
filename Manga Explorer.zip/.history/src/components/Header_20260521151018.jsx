import { Link } from "react-router-dom";

export default function Header() {
    return (
        <header className="flex items-center justify-between px-6 py-4 bg-black text-white">
            
            {/* Logo */}
            <h1 className="text-xl font-bold text-purple-400">
                Manga Explorer
            </h1>

            {/* Navigation */}
            <nav className="flex gap-6 text-sm">
                <Link to="/">Home</Link>
                <span className="opacity-50">Favorites</span>
                <span className="opacity-50">About</span>
            </nav>

        </header>
    );
}