// src/components/MangaCard.jsx
import { useNavigate } from "react-router";

export default function MangaCard({ manga }) {
    const navigate = useNavigate();

    return (
        <div
            onClick={() => navigate(`/manga/${manga.id}`)}
            className="group cursor-pointer relative bg-gray-900/80 backdrop-blur-sm border border-purple-900/30 rounded-2xl p-4 transition-all duration-300 hover:scale-[1.03] hover:border-purple-500/70 hover:shadow-2xl hover:shadow-purple-900/40 hover:bg-gray-900/95"
        >
            {/* Manga cover placeholder */}
            <div className="h-44 rounded-xl mb-4 overflow-hidden relative bg-gradient-to-br from-purple-900/60 via-gray-800 to-blue-900/40 flex items-center justify-center shadow-inner">
                {/* Decorative pattern */}
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_40%,rgba(139,92,246,0.4),transparent_70%)] group-hover:opacity-80 transition-opacity duration-300"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-16 h-16 rounded-full bg-purple-600/20 backdrop-blur-sm flex items-center justify-center text-3xl shadow-lg shadow-purple-900/30">
                        📖
                    </div>
                </div>
                {/* Shine effect on hover */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <span className="absolute bottom-2 left-2 text-xs text-white/70 bg-black/50 px-2 py-0.5 rounded-md backdrop-blur-sm">
                    Vol. 1
                </span>
            </div>

            {/* Title */}
            <h3 className="text-white font-bold text-lg leading-tight mb-1 group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-purple-300 group-hover:to-blue-300 transition-all duration-200">
                {manga.title}
            </h3>

            {/* Rating and badge */}
            <div className="flex items-center gap-2 mt-2">
                <div className="flex items-center gap-1 bg-purple-950/60 px-2 py-0.5 rounded-full text-sm">
                    <span className="text-yellow-400 drop-shadow-sm">⭐</span>
                    <span className="text-purple-200 font-semibold">{manga.rating}</span>
                </div>
                <span className="text-xs text-gray-500 bg-gray-800/70 px-2 py-0.5 rounded-full">Shounen</span>
            </div>
        </div>
    );
}