export default function MangaCard({ manga, onClick }) {
    return (
        // Card container with hover effects
        <div
            onClick={onClick}
            className="
                cursor-pointer
                rounded-2xl
                overflow-hidden
                bg-gray-900
                shadow-lg
                transform
                transition-all
                duration-300
                hover:scale-105
                hover:shadow-purple-500/30
            "
        >
            {/* Manga cover image */}
            <img
                src={manga.image}
                alt={manga.title}
                className="w-full h-64 object-cover"
            />

            {/* Card content */}
            <div className="p-4">
                <h3 className="text-white font-semibold text-lg">
                    {manga.title}
                </h3>

                {/* Rating badge */}
                <p className="text-sm text-purple-300 mt-1">
                    ⭐ {manga.rating}
                </p>
            </div>
        </div>
    );
}