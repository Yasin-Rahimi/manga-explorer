import { Link } from "react-router-dom";

export default function Header() {
    return (
        // Top navigation bar
        <header className="w-full flex justify-between items-center px-8 py-5 bg-gray-950 text-white">
            
            {/* Logo */}
            <h1 className="text-xl font-bold text-purple-400">
                Manga Explorer
            </h1>

            {/* Navigation links */}
            <nav className="flex gap-6 text-sm">
                <Link to="/" className="hover:text-purple-400">
                    Home
                </Link>

                <Link to="/favorites" className="hover:text-purple-400">
                    Favorites
                </Link>

                <Link to="/about" className="hover:text-purple-400">
                    About
                </Link>
            </nav>
        </header>
    );
}